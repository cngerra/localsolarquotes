<?php 
	include 'header-html.php'; 
?>
<div class="container req-page">
	<div class="row">
		<div class="col-lg-12">
			<h1>Privacy Policy</h1><br>
			<?php include 'privacy-policy-copy.php'; ?>	
		</div>
	</div>
</div>
</body>
</html>