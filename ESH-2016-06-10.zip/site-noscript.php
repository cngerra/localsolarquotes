<noscript style="position: fixed; z-index: 999999; top: 0; background-color: #b30000; width: 100%; padding: 10px; text-align: center; font-size: 16px; color: #f8eaea;">
<span class="fa fa-exclamation-triangle" style="margin-right: 5px; font-size: 80%;"></span>JavaScript is currently disabled.<br>This site requires JavaScript to function correctly.
</noscript>
