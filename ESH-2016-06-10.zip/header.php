<header class="black-bottom-border header-article paddingtb20">
	<div class="container">
		<div class="row font0">
			<div class="col-xs-12 col-md-3 vcenter">
				<div class="header-logo">
					<img width="175" height="77" class="img-responsive logo" alt="" src="/img/white-bg-small-yellow.png">
				</div>
			</div>
		</div>
	</div>
</header>
