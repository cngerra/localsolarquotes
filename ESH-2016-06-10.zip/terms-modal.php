<div class="modal fade req-modal" tabindex="1" id="terms-modal">
	<div class="modal-dialog">
		<div class="modal-content" style="margin-top: 243px;">
			<div class="modal-header">
				<button aria-label="Close" data-dismiss="modal" class="close" type="button"><span aria-hidden="true">&times;</span></button>
				<h1 class="modal-title">
					Terms of Service
				</h1>
			</div>
			<div class="modal-body">
				<div class="req-page">
					<?php include 'terms-copy.php'; ?>
				</div>
			</div>
		</div>
	</div>
</div>
