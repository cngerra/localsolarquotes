<?php
$Response = array('Error' => 0);
echo json_encode($Response);
