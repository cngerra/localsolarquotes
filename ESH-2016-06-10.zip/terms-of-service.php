<?php 
	include 'header-html.php'; 
?>
<div class="container req-page">
	<div class="row">	
		<div class="col-lg-12">
			<h1>Terms of Service</h1><br>
			<?php include 'terms-copy.php'; ?>	
		</div>
	</div>
</div>
</body>
</html>

