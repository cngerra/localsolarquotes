<header class="black-bottom-border header-article paddingtb20">
	<div class="container">
		<div class="row font0">
			<a href="/resources-and-articles" class="col-lg-3 col-md-3 hidden-sm hidden-xs vcenter">
				<img width="175" height="77" class="img-responsive logo" alt="" src="/img/white-bg-small-yellow.png">
			</a>
			<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 vcenter">
				<div class="navbar-header">
					<a href="/resources-and-articles" class="navbar-brand visible-sm visible-xs">
						<img width="175" height="77" class="img-responsive logo" alt="" src="/img/white-bg-small-yellow.png">
					</a>
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#topnav" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<div class="collapse navbar-collapse" id="topnav">
					<ul class="nav navbar-nav">
						<li><a href="#">Immediate Assistance</a></li>
						<li><a href="#">Everything About Grants</a></li>
						<li><a href="#">Creme Mains Veloutee</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</header>
